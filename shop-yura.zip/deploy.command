#!/usr/bin/env bash
# Подвійний клік на macOS — і сайт на хостингу.
# Перший раз: chmod +x deploy.command
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Не встановлено Node.js — завантажте з https://nodejs.org"
  read -r -p "Натисніть Enter..."
  exit 1
fi
node deploy.mjs "$@"
read -r -p "Натисніть Enter, щоб закрити..."
