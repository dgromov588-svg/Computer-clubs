@echo off
REM ============================================================
REM  Автоматичний деплой (Windows) · Скупка антикваріату Дніпро
REM  Використання:  deploy.bat
REM                 deploy.bat --url=https://antique.dp.ua
REM ============================================================
chcp 65001 >nul
setlocal

echo.
echo =====================================================
echo   СКУПКА АНТИКВАРІАТУ ДНІПРО · ДЕПЛОЙ
echo =====================================================
echo.

if not exist "node_modules" (
  echo ^> Встановлення залежностей...
  call npm install --no-audit --no-fund
  if errorlevel 1 goto :fail
)

echo ^> Перевірка TypeScript...
call npx tsc --noEmit

echo ^> Збірка проекту...
call npm run build
if errorlevel 1 goto :fail

echo ^> Автоналаштування деплою...
call node scripts/prepare-deploy.mjs %*
if errorlevel 1 goto :fail

echo.
echo =====================================================
echo   ГОТОВО. Завантажте вміст dist\ у public_html\
echo   Або використайте deploy.zip
echo =====================================================
echo.
goto :eof

:fail
echo.
echo [ПОМИЛКА] Деплой перервано. Перевірте повідомлення вище.
exit /b 1
