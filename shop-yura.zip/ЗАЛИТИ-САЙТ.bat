@echo off
REM ============================================================
REM  Подвійний клік — і сайт «Салон АнтикварЪ» на хостингу.
REM  (Windows. Потрібен Node.js: https://nodejs.org)
REM ============================================================
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (
  echo.
  echo [ПОМИЛКА] Не встановлено Node.js. Завантажте з https://nodejs.org
  echo.
  pause
  exit /b 1
)
node deploy.mjs %*
echo.
pause
