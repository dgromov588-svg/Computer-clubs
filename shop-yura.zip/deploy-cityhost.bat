@echo off
REM Сумісність: тепер уся логіка в deploy.mjs. Простіше — подвійний клік по ЗАЛИТИ-САЙТ.bat
chcp 65001 >nul
cd /d "%~dp0"
node deploy.mjs %*
