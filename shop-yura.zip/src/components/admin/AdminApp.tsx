import { useState, useEffect } from 'react'
import { AdminLogin } from './AdminLogin'
import { AdminDashboard } from './AdminDashboard'

const AUTH_KEY = 'admin_auth_v1'
const AUTH_DURATION = 8 * 60 * 60 * 1000 // 8 годин

interface AuthState {
  authenticated: boolean
  expiresAt: number
}

export function AdminApp() {
  const [auth, setAuth] = useState<AuthState>({ authenticated: false, expiresAt: 0 })

  useEffect(() => {
    const check = () => {
      try {
        const raw = localStorage.getItem(AUTH_KEY)
        if (raw) {
          const parsed: AuthState = JSON.parse(raw)
          if (parsed.expiresAt > Date.now()) {
            setAuth(parsed)
            return
          }
        }
      } catch {
        // ignore
      }
      setAuth({ authenticated: false, expiresAt: 0 })
    }
    check()
  }, [])

  const handleLogin = () => {
    const newAuth: AuthState = {
      authenticated: true,
      expiresAt: Date.now() + AUTH_DURATION,
    }
    localStorage.setItem(AUTH_KEY, JSON.stringify(newAuth))
    setAuth(newAuth)
  }

  const handleLogout = () => {
    localStorage.removeItem(AUTH_KEY)
    setAuth({ authenticated: false, expiresAt: 0 })
  }

  if (!auth.authenticated) {
    return <AdminLogin onLogin={handleLogin} />
  }

  return <AdminDashboard onLogout={handleLogout} />
}
