import { useState } from 'react'
import {
  LayoutDashboard,
  Inbox,
  MessageSquare,
  Settings as SettingsIcon,
  LogOut,
  Bell,
  Search,
} from 'lucide-react'
import { loadRequests, saveRequests, ClientRequest } from '../../lib/storage'
import { LogoMark } from '../Logo'
import { DashboardOverview } from './DashboardOverview'
import { RequestsList } from './RequestsList'
import { RequestDetail } from './RequestDetail'
import { SettingsPanel } from './SettingsPanel'
import { MessagesPanel } from './MessagesPanel'

type Tab = 'overview' | 'requests' | 'messages' | 'settings'

interface AdminDashboardProps {
  onLogout: () => void
}

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [tab, setTab] = useState<Tab>('overview')
  const [requests, setRequests] = useState<ClientRequest[]>(() => loadRequests())
  const [selectedRequest, setSelectedRequest] = useState<string | null>(null)

  const updateRequests = (next: ClientRequest[]) => {
    setRequests(next)
    saveRequests(next)
  }

  const updateRequest = (id: string, updater: (r: ClientRequest) => ClientRequest): void => {
    const next = requests.map((r) => (r.id === id ? updater(r) : r))
    updateRequests(next)
  }

  const selected = selectedRequest ? requests.find((r) => r.id === selectedRequest) : null

  const nav: { id: Tab; label: string; icon: any; badge?: number }[] = [
    { id: 'overview', label: 'Огляд', icon: LayoutDashboard },
    {
      id: 'requests',
      label: 'Заявки',
      icon: Inbox,
      badge: requests.filter((r) => r.status === 'new').length || undefined,
    },
    {
      id: 'messages',
      label: 'Повідомлення',
      icon: MessageSquare,
      badge: requests.reduce(
        (acc, r) =>
          acc +
          (r.messages.filter((m) => m.author === 'client' && Date.now() - m.timestamp < 24 * 60 * 60 * 1000).length > 0
            ? 1
            : 0),
        0,
      ) || undefined,
    },
    { id: 'settings', label: 'Налаштування', icon: SettingsIcon },
  ]

  return (
    <div className="min-h-screen bg-stone-100">
      {/* Topbar */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30">
        <div className="px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <LogoMark className="w-11 h-11 drop-shadow" />
            <div>
              <div className="font-display font-bold text-stone-900">Панель власника</div>
              <div className="text-xs text-stone-500">Салон «АнтикварЪ» · (050) 562-35-23</div>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 flex-1 max-w-md mx-6">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                placeholder="Шукати заявки, клієнтів..."
                className="w-full pl-10 pr-4 py-2 rounded-lg bg-stone-50 border border-stone-200 text-sm focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-100"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button className="relative p-2 rounded-lg hover:bg-stone-100 text-stone-600">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500"></span>
            </button>
            <a
              href="#"
              className="hidden sm:inline-flex items-center gap-2 px-3 py-2 text-sm text-stone-600 hover:bg-stone-100 rounded-lg"
            >
              На сайт
            </a>
            <button
              onClick={onLogout}
              className="inline-flex items-center gap-2 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 rounded-lg"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Вихід</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="hidden md:block w-64 bg-white border-r border-stone-200 min-h-[calc(100vh-4rem)] sticky top-16">
          <nav className="p-4 space-y-1">
            {nav.map((item) => {
              const Icon = item.icon
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setTab(item.id)
                    setSelectedRequest(null)
                  }}
                  className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    tab === item.id
                      ? 'bg-amber-50 text-amber-900 border border-amber-200'
                      : 'text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </span>
                  {item.badge && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-xs font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              )
            })}
          </nav>

          <div className="p-4 border-t border-stone-200 mt-4">
            <div className="bg-gradient-to-br from-stone-900 to-amber-900 rounded-2xl p-4 text-amber-50">
              <div className="text-xs uppercase tracking-wider text-amber-300">
                Порада
              </div>
              <div className="mt-2 text-sm font-semibold">
                Відповідайте на нові заявки протягом 15 хвилин — це підвищує
                конверсію у 3 рази!
              </div>
            </div>
          </div>
        </aside>

        {/* Mobile bottom nav */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-stone-200 z-30 grid grid-cols-4">
          {nav.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => {
                  setTab(item.id)
                  setSelectedRequest(null)
                }}
                className={`relative flex flex-col items-center justify-center py-2 text-xs ${
                  tab === item.id ? 'text-amber-700' : 'text-stone-500'
                }`}
              >
                <Icon className="w-5 h-5 mb-1" />
                {item.label}
                {item.badge && (
                  <span className="absolute top-1 right-1/2 translate-x-3 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            )
          })}
        </nav>

        {/* Main */}
        <main className="flex-1 min-w-0 pb-16 md:pb-0">
          {selected ? (
            <RequestDetail
              request={selected}
              onBack={() => setSelectedRequest(null)}
              onUpdate={(updater) => updateRequest(selected.id, updater)}
              onDelete={() => {
                updateRequests(requests.filter((r) => r.id !== selected.id))
                setSelectedRequest(null)
              }}
            />
          ) : tab === 'overview' ? (
            <DashboardOverview
              requests={requests}
              onSelectRequest={(id) => {
                setSelectedRequest(id)
                setTab('requests')
              }}
            />
          ) : tab === 'requests' ? (
            <RequestsList
              requests={requests}
              onSelect={setSelectedRequest}
              onUpdate={updateRequests}
            />
          ) : tab === 'messages' ? (
            <MessagesPanel
              requests={requests}
              onSelect={setSelectedRequest}
            />
          ) : (
            <SettingsPanel />
          )}
        </main>
      </div>
    </div>
  )
}
