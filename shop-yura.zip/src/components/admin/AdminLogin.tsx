import { useState } from 'react'
import { Lock, ArrowLeft, Eye, EyeOff } from 'lucide-react'
import { LogoMark } from '../Logo'
import { loadSettings } from '../../lib/storage'

interface AdminLoginProps {
  onLogin: () => void
}

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [showPwd, setShowPwd] = useState(false)
  const [loading, setLoading] = useState(false)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setTimeout(() => {
      const settings = loadSettings()
      if (password === settings.ownerPassword) {
        onLogin()
      } else {
        setError('Невірний пароль. Спробуйте ще раз.')
        setLoading(false)
      }
    }, 400)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-950 via-stone-900 to-amber-950 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decor */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl"></div>

      <div className="relative w-full max-w-md">
        <a
          href="#"
          className="inline-flex items-center gap-2 text-amber-200/70 hover:text-amber-300 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Повернутися на сайт
        </a>

        <div className="bg-stone-900/80 backdrop-blur-xl rounded-3xl border border-amber-700/30 shadow-2xl p-8">
          <div className="flex items-center justify-center mb-6">
            <LogoMark className="w-28 h-28 drop-shadow-[0_12px_24px_rgba(0,0,0,0.6)]" />
          </div>

          <h1 className="text-2xl font-black text-amber-50 text-center">
            Панель власника
          </h1>
          <p className="mt-2 text-sm text-amber-200/60 text-center">
            Введіть пароль для доступу до управління заявками
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-amber-400">
                <Lock className="w-5 h-5" />
              </div>
              <input
                required
                type={showPwd ? 'text' : 'password'}
                placeholder="Пароль"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
                className="w-full pl-12 pr-12 py-3.5 rounded-xl bg-stone-800/80 border border-amber-700/30 text-amber-50 placeholder-amber-200/30 focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-500/20 transition"
              />
              <button
                type="button"
                onClick={() => setShowPwd(!showPwd)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-amber-200/60 hover:text-amber-300"
              >
                {showPwd ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {error && (
              <div className="bg-rose-500/20 border border-rose-500/40 text-rose-300 text-sm rounded-xl px-4 py-3">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-600 text-stone-950 font-bold shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50 hover:scale-[1.01] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Перевірка...' : 'Увійти'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-amber-700/20">
            <p className="text-xs text-amber-200/50 text-center">
              🔒 Захищений доступ · Сесія діє 8 годин
            </p>
            <p className="mt-2 text-xs text-amber-200/40 text-center">
              Демо-пароль: <code className="bg-stone-800 px-2 py-0.5 rounded text-amber-300">admin</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
