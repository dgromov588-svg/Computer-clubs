import { useState, useEffect } from 'react'
import {
  Save,
  Bell,
  MessageSquare,
  RefreshCw,
  Trash2,
  Download,
  Upload,
  Eye,
  EyeOff,
  Check,
} from 'lucide-react'
import {
  Settings,
  loadSettings,
  saveSettings,
  loadRequests,
  formatDate,
  STORAGE_KEY,
} from '../../lib/storage'
import { DeployPanel } from './DeployPanel'

export function SettingsPanel() {
  const [settings, setSettings] = useState<Settings>(loadSettings())
  const [showPwd, setShowPwd] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    setSettings(loadSettings())
  }, [])

  const save = () => {
    saveSettings(settings)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const resetDemoData = () => {
    if (
      confirm('Скинути усі дані до демо-стану? Ваші заявки будуть замінені на приклади.')
    ) {
      localStorage.removeItem(STORAGE_KEY)
      window.location.reload()
    }
  }

  const exportAll = () => {
    const requests = loadRequests()
    const data = { settings, requests }
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `antique_backup_${new Date().toISOString().split('T')[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const importFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string)
        if (data.settings) saveSettings(data.settings)
        if (data.requests) {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(data.requests))
          window.location.reload()
        }
      } catch (err) {
        alert('Помилка імпорту файлу')
      }
    }
    reader.readAsText(file)
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-stone-900">Налаштування</h1>
          <p className="mt-1 text-stone-500 text-sm">
            Параметри роботи панелі, сповіщення та дані
          </p>
        </div>
        <button
          onClick={save}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-600 text-stone-950 font-bold hover:shadow-lg hover:shadow-amber-500/30 transition-all"
        >
          {saved ? (
            <>
              <Check className="w-4 h-4" />
              Збережено!
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Зберегти зміни
            </>
          )}
        </button>
      </div>

      <div className="space-y-6">
        {/* Owner info */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-4">Інформація про власника</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-stone-700">Ім'я власника</label>
              <input
                value={settings.ownerName}
                onChange={(e) => setSettings({ ...settings, ownerName: e.target.value })}
                className="mt-1 w-full px-4 py-2.5 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-stone-700">Назва компанії</label>
              <input
                value={settings.companyName}
                onChange={(e) => setSettings({ ...settings, companyName: e.target.value })}
                className="mt-1 w-full px-4 py-2.5 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>
        </section>

        {/* Security */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-1">Безпека</h2>
          <p className="text-sm text-stone-500 mb-4">
            Змініть пароль для доступу до панелі. У реальному проекті використовуйте хешування!
          </p>
          <div className="relative max-w-sm">
            <label className="text-sm font-semibold text-stone-700">Пароль</label>
            <input
              type={showPwd ? 'text' : 'password'}
              value={settings.ownerPassword}
              onChange={(e) => setSettings({ ...settings, ownerPassword: e.target.value })}
              className="mt-1 w-full px-4 py-2.5 pr-12 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400"
            />
            <button
              onClick={() => setShowPwd(!showPwd)}
              className="absolute right-3 bottom-2.5 text-stone-500 hover:text-stone-700"
            >
              {showPwd ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </section>

        {/* Currency */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-4">Валюта та курси</h2>
          <div className="grid sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-semibold text-stone-700">За замовчуванням</label>
              <select
                value={settings.defaultCurrency}
                onChange={(e) =>
                  setSettings({ ...settings, defaultCurrency: e.target.value as any })
                }
                className="mt-1 w-full px-4 py-2.5 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400"
              >
                <option value="UAH">UAH (грн)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-semibold text-stone-700">Курс USD</label>
              <input
                type="number"
                step="0.01"
                value={settings.exchangeRates.USD}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    exchangeRates: {
                      ...settings.exchangeRates,
                      USD: Number(e.target.value),
                    },
                  })
                }
                className="mt-1 w-full px-4 py-2.5 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-stone-700">Курс EUR</label>
              <input
                type="number"
                step="0.01"
                value={settings.exchangeRates.EUR}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    exchangeRates: {
                      ...settings.exchangeRates,
                      EUR: Number(e.target.value),
                    },
                  })
                }
                className="mt-1 w-full px-4 py-2.5 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>
        </section>

        {/* Notifications */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-4 flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-600" />
            Сповіщення
          </h2>
          <div className="space-y-3">
            {[
              {
                key: 'newRequest',
                label: 'Нові заявки',
                desc: 'Сповіщати про нові звернення клієнтів',
              },
              {
                key: 'statusChange',
                label: 'Зміна статусу',
                desc: 'Сповіщати при зміні статусу заявки',
              },
              {
                key: 'offerReceived',
                label: 'Зустрічна пропозиція',
                desc: 'Сповіщати коли клієнт пропонує свою ціну',
              },
            ].map((item) => (
              <label
                key={item.key}
                className="flex items-center justify-between gap-3 p-3 rounded-lg bg-stone-50 hover:bg-stone-100 cursor-pointer"
              >
                <div>
                  <div className="font-semibold text-stone-900">{item.label}</div>
                  <div className="text-xs text-stone-500">{item.desc}</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.notifications[item.key as keyof typeof settings.notifications]}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      notifications: {
                        ...settings.notifications,
                        [item.key]: e.target.checked,
                      },
                    })
                  }
                  className="w-5 h-5 rounded accent-amber-500 cursor-pointer"
                />
              </label>
            ))}
          </div>
        </section>

        {/* Auto-reply */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-1 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-amber-600" />
            Автовідповідь
          </h2>
          <p className="text-sm text-stone-500 mb-4">
            Текст, який автоматично надсилається клієнту при створенні заявки
          </p>
          <label className="flex items-center gap-2 mb-3">
            <input
              type="checkbox"
              checked={settings.autoResponder.enabled}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  autoResponder: { ...settings.autoResponder, enabled: e.target.checked },
                })
              }
              className="w-5 h-5 rounded accent-amber-500"
            />
            <span className="font-semibold text-stone-700">Увімкнути автовідповідь</span>
          </label>
          <textarea
            rows={3}
            value={settings.autoResponder.text}
            onChange={(e) =>
              setSettings({
                ...settings,
                autoResponder: { ...settings.autoResponder, text: e.target.value },
              })
            }
            className="w-full px-4 py-2.5 rounded-lg bg-stone-50 border border-stone-200 focus:outline-none focus:border-amber-400 resize-none"
          />
        </section>

        {/* Data management */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-1 flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-amber-600" />
            Резервна копія
          </h2>
          <p className="text-sm text-stone-500 mb-4">
            Збережіть дані на свій пристрій або відновіть з резервної копії
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={exportAll}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold"
            >
              <Download className="w-4 h-4" />
              Експорт JSON
            </button>
            <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold cursor-pointer">
              <Upload className="w-4 h-4" />
              Імпорт JSON
              <input type="file" accept=".json" onChange={importFile} className="hidden" />
            </label>
            <button
              onClick={resetDemoData}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold"
            >
              <Trash2 className="w-4 h-4" />
              Скинути демо-дані
            </button>
          </div>
        </section>

        {/* Заливка з телефону */}
        <DeployPanel />

        {/* Deployment */}
        <section className="bg-white rounded-2xl border border-stone-200 p-6">
          <h2 className="font-bold text-stone-900 mb-1 flex items-center gap-2">
            <Upload className="w-5 h-5 text-amber-600" />
            Публікація на хостинг
          </h2>
          <p className="text-sm text-stone-500 mb-4">
            Сайт збирається в один файл — достатньо завантажити вміст папки{' '}
            <code className="bg-stone-100 px-1.5 py-0.5 rounded text-xs">dist/</code> у{' '}
            <code className="bg-stone-100 px-1.5 py-0.5 rounded text-xs">public_html/</code>
          </p>

          <div className="space-y-3">
            {[
              {
                label: 'Швидкий деплой (одна команда)',
                cmd: 'bash deploy.sh',
              },
              {
                label: 'Windows',
                cmd: 'deploy.bat',
              },
              {
                label: 'З вашим доменом (для SEO)',
                cmd: 'node scripts/prepare-deploy.mjs --url=https://ваш-домен.ua',
              },
              {
                label: 'Ручний варіант',
                cmd: 'npm run build && node scripts/prepare-deploy.mjs',
              },
            ].map((row) => (
              <div key={row.cmd}>
                <div className="text-xs font-semibold text-stone-600 mb-1">{row.label}</div>
                <div className="flex items-center gap-2">
                  <code className="flex-1 px-3 py-2 rounded-lg bg-stone-900 text-amber-200 text-xs font-mono overflow-x-auto">
                    {row.cmd}
                  </code>
                  <button
                    onClick={() => navigator.clipboard.writeText(row.cmd)}
                    className="px-3 py-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold shrink-0"
                  >
                    Копіювати
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 grid sm:grid-cols-2 gap-3 text-sm">
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
              <div className="font-bold text-emerald-900 mb-1">✓ Авто-скрипт робить</div>
              <ul className="text-xs text-emerald-800 space-y-0.5">
                <li>· відносні шляхи (працює в підпапках)</li>
                <li>· 404.html для SPA-фолбеку</li>
                <li>· sw.js — офлайн-режим (PWA)</li>
                <li>· robots.txt, sitemap.xml, SEO-теги</li>
                <li>· deploy.zip для FTP</li>
              </ul>
            </div>
            <div className="p-3 rounded-xl bg-stone-50 border border-stone-200">
              <div className="font-bold text-stone-800 mb-1">Готові конфіги</div>
              <ul className="text-xs text-stone-600 space-y-0.5">
                <li>· <code>.htaccess</code> — Apache</li>
                <li>· <code>nginx.conf.example</code> — Nginx</li>
                <li>· <code>netlify.toml</code> — Netlify</li>
                <li>· <code>vercel.json</code> — Vercel</li>
                <li>· GitHub Actions — авто-деплой</li>
              </ul>
            </div>
          </div>

          <p className="mt-4 text-xs text-stone-500">
            Повна інструкція — у файлі{' '}
            <code className="bg-stone-100 px-1.5 py-0.5 rounded">DEPLOY.md</code>
          </p>
        </section>

        {/* System info */}
        <section className="bg-gradient-to-br from-stone-900 to-amber-900 rounded-2xl text-amber-50 p-6">
          <h2 className="font-bold mb-3">Інформація про систему</h2>
          <div className="grid sm:grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-amber-200/60">Версія</div>
              <div className="font-semibold">1.0.0</div>
            </div>
            <div>
              <div className="text-amber-200/60">Збережено заявок</div>
              <div className="font-semibold">{loadRequests().length}</div>
            </div>
            <div>
              <div className="text-amber-200/60">Дата</div>
              <div className="font-semibold">{formatDate(Date.now())}</div>
            </div>
            <div>
              <div className="text-amber-200/60">Сховище</div>
              <div className="font-semibold">Локальне (localStorage)</div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
