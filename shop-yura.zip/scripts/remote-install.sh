#!/bin/sh
# ==================================================================
#  Виконується НА СЕРВЕРІ CityHost (викликається deploy-cityhost.*)
#
#  1. Визначає папку сайту (або бере вказану)
#  2. Робить резервну копію поточного сайту (зберігає 5 останніх)
#  3. Розпаковує нову версію
#  4. Виставляє права 755/644
#
#  Аргументи:  $1 — шлях до папки сайту (необовʼязково)
#              $2 — "clean", щоб видалити старі файли перед заливкою
# ==================================================================
set -e

ARCHIVE="$HOME/antikvar-deploy.tgz"
UPLOAD="$HOME/.antikvar-upload"
TARGET="$1"
MODE="$2"

say() { printf '%s\n' "$*"; }

# Джерело: папка (deploy.mjs) або архів (старі .sh/.bat)
if [ -d "$UPLOAD" ] && [ -f "$UPLOAD/index.html" ]; then
  SOURCE="dir"
elif [ -f "$ARCHIVE" ]; then
  SOURCE="tgz"
else
  say "✗ Нова версія сайту не знайдена на сервері — завантаження не вдалося"
  exit 1
fi

# ---------- 1. Пошук папки сайту ----------
if [ -z "$TARGET" ]; then
  CANDIDATES=""
  COUNT=0
  # CityHost: ~/www/<домен>/   ·  інші варіанти: ~/<домен>/www, ~/public_html
  for d in "$HOME"/www/*/ "$HOME"/*/www/ "$HOME"/public_html/; do
    [ -d "$d" ] || continue
    d="${d%/}"
    CANDIDATES="$CANDIDATES
   $d"
    COUNT=$((COUNT + 1))
    FOUND="$d"
  done

  if [ "$COUNT" -eq 1 ]; then
    TARGET="$FOUND"
    say "▸ Знайдено папку сайту: $TARGET"
  else
    say ""
    if [ "$COUNT" -eq 0 ]; then
      say "✗ Не знайдено папку сайту. Вміст домашньої папки:"
      ls -la "$HOME"
    else
      say "✗ Знайдено кілька можливих папок сайту:$CANDIDATES"
    fi
    say ""
    say "  Запустіть ще раз із вказаною папкою, наприклад:"
    say "    node deploy.mjs --path=\$HOME/www/ваш-домен.ua"
    rm -rf "$ARCHIVE" "$UPLOAD" "$0"
    exit 2
  fi
fi

# ---------- Захист від помилок ----------
case "$TARGET" in
  "$HOME"/?*) ;;
  *)
    say "✗ Небезпечний шлях «$TARGET» — дозволено лише всередині $HOME"
    rm -rf "$ARCHIVE" "$UPLOAD" "$0"
    exit 3
    ;;
esac
mkdir -p "$TARGET"

# ---------- 2. Резервна копія ----------
BACKUPS="$HOME/site-backups"
mkdir -p "$BACKUPS"
STAMP=$(date +%Y%m%d-%H%M%S)
if [ -n "$(ls -A "$TARGET" 2>/dev/null)" ]; then
  tar czf "$BACKUPS/site-$STAMP.tgz" -C "$TARGET" . 2>/dev/null || true
  say "▸ Резервна копія: $BACKUPS/site-$STAMP.tgz"
  # залишаємо 5 останніх
  ls -1t "$BACKUPS"/site-*.tgz 2>/dev/null | tail -n +6 | while read -r old; do rm -f "$old"; done
fi

# ---------- 3. Очищення (лише з прапорцем clean) ----------
if [ "$MODE" = "clean" ]; then
  find "$TARGET" -mindepth 1 -maxdepth 1 ! -name '.well-known' ! -name 'cgi-bin' -exec rm -rf {} +
  say "▸ Старі файли видалено (збережено .well-known, cgi-bin)"
fi

# ---------- 4. Розпаковка ----------
if [ "$SOURCE" = "dir" ]; then
  cp -R "$UPLOAD"/. "$TARGET"/
  rm -rf "$UPLOAD"
else
  tar xzf "$ARCHIVE" -C "$TARGET"
  rm -f "$ARCHIVE"
fi
find "$TARGET" -type d -exec chmod 755 {} + 2>/dev/null || true
find "$TARGET" -type f -exec chmod 644 {} + 2>/dev/null || true

say "✓ Сайт оновлено у $TARGET"
say "  Файлів: $(find "$TARGET" -type f | wc -l)"
say "  Відкат до попередньої версії:"
say "    tar xzf $BACKUPS/site-$STAMP.tgz -C $TARGET"

rm -f "$0"
