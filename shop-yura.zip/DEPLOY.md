# 🚀 Автоналаштування деплою

## 📱 З телефону (без компʼютера)

**Як це працює:** проект лежить на GitHub. Після будь-якої зміни (або натискання кнопки)
GitHub сам збирає сайт і дає хостингу команду оновитися. Хостинг забирає нову версію
по HTTPS, тому обмеження CityHost за IP для SSH і FTP тут не заважає.

### Налаштування (один раз, усе з браузера телефону)

**1. Завантажити проект на GitHub**
- Зареєструйтесь на [github.com](https://github.com) → **New repository** → назва `antikvar`
  → **Private** → Create.
- На сторінці репозиторію: **Add file → Upload files** → виберіть усі файли проекту.
  Папки `node_modules` і `dist` не потрібні.

**2. Придумати секрет** — будь-які 20+ символів, напр. `Antikvar-2026-Dnipro-x7Kq9`.

**3. Додати налаштування в GitHub** (репозиторій → **Settings → Secrets and variables → Actions**):
| Вкладка | Назва | Значення |
|---|---|---|
| Secrets → New repository secret | `DEPLOY_HOOK_SECRET` | ваш секрет із кроку 2 |
| Variables → New repository variable | `SITE_URL` | `https://ваш-домен.ua` |

**4. Перша заливка вручну (лише один раз)**
- GitHub → **Actions → «📱 Заливка на CityHost» → Run workflow**.
- Перший запуск закінчиться помилкою «Перша заливка вручну». Так і має бути: на хостингу
  ще немає приймача оновлень.
- Внизу сторінки запуску завантажте архів **site-for-hosting**.
- Панель CityHost → **Хостинг 2.0 → FTP → Файловий менеджер** → папка сайту
  (`www/ваш-домен.ua`) → завантажте архів → **Розпакувати**.
- Знову натисніть **Run workflow** — тепер буде зелена галочка ✅.

**5. Кнопка в адмінці** — відкрийте `ваш-домен.ua/#admin` → **Налаштування →
«Заливка з телефону»**, вставте назву репозиторію та токен GitHub (інструкція там же).

### Щоденне використання
| Що зробити | Як |
|---|---|
| Змінити текст, телефон, фото | github.com → файл → ✏️ Edit → **Commit changes** → сайт оновиться сам за 1–2 хв |
| Просто перезалити сайт | адмінка → Налаштування → **Залити зараз** |
| Або | застосунок GitHub → Actions → «📱 Заливка на CityHost» → **Run workflow** |

Де що міняти: телефон і адреса — `src/lib/hours.ts`, перелік «Купуємо» — `src/lib/categories.ts`.

Перед кожним оновленням хостинг зберігає копію поточного сайту в `~/site-backups/`
(5 останніх). Якщо збірка зламана, сайт **не змінюється**.

---

## ⭐ CityHost — ваш хостинг (готово до запуску)

| Параметр | Значення |
|---|---|
| Хост | `amarok.cityhost.com.ua` |
| Логін | `ch9ca38181` |
| Порт | `22` |
| Пароль | **не зберігається в проекті** — вводиться при запуску |

### Перед першим запуском (1 раз)
1. Панель CityHost → **Хостинг 2.0 → Керування → SSH → Дозволені IP → Додати IP**.
   Вимкніть VPN і натисніть «додати поточний IP». Без цього CityHost не пустить по SSH.
2. Переконайтеся, що сайт (домен) уже доданий у **Хостинг 2.0 → Сайти**.

### Заливка однією командою

```bash
node deploy.mjs
```

Або **подвійний клік**:
- Windows → `ЗАЛИТИ-САЙТ.bat`
- macOS → `deploy.command` (перший раз: `chmod +x deploy.command`)

Працює на Windows / macOS / Linux, потрібен лише [Node.js 18+](https://nodejs.org).
Програми ssh/scp не потрібні. Пароль запитується **один раз** (приховано).

Перший запуск з адресою сайту (запамʼятається):
```bash
node deploy.mjs --url=https://ваш-домен.ua
```

Додаткові параметри: `--path=...` (папка на сервері), `--clean` (видалити старі файли),
`--skip-build` (залити без збірки), `--help`.

Хочете команду `npm run deploy`? Додайте в `package.json` → `"scripts"`:
`"deploy": "node deploy.mjs"`.

Скрипт:
1. збирає сайт (`npm run build` + `prepare-deploy.mjs`);
2. пакує `dist/` в архів;
3. підключається по SSH (пароль запитується **один раз**);
4. **сам знаходить папку сайту** (`~/www/<домен>`);
5. робить **резервну копію** поточного сайту в `~/site-backups/` (5 останніх);
6. розпаковує нову версію та виставляє права 755/644.

Якщо на акаунті кілька сайтів — скрипт покаже нумерований список, ви оберете номер,
і вибір збережеться в `.env.deploy`. Наступні заливки — без жодних запитань, крім пароля.

### Відкат до попередньої версії
```bash
ssh ch9ca38181@amarok.cityhost.com.ua
ls ~/site-backups/
tar xzf ~/site-backups/site-ДАТА.tgz -C ~/www/ваш-домен.ua
```

### Без пароля (рекомендовано) — SSH-ключ
```bash
ssh-keygen -t ed25519            # Enter на всі питання
ssh-copy-id ch9ca38181@amarok.cityhost.com.ua
```
Після цього `node deploy.mjs` знайде ключ сам і не питатиме пароль — заливка повністю автоматична.

> 🔐 **Безпека:** пароль від SSH було надіслано у відкритому чаті. Після першої заливки
> змініть його в панелі CityHost (Хостинг 2.0 → Керування → SSH) і перейдіть на SSH-ключ.

---

Сайт **«Скупка антикваріату — Юрій»** (Дніпро) — статичний SPA, збирається в **один файл** `index.html` + зображення.

---

## ⚡ Швидкий старт (3 команди)

```bash
npm install
npm run build
node scripts/prepare-deploy.mjs
```

Після цього в корені з'явиться **`deploy.zip`** — просто завантажте його вміст у `public_html/` на хостинг.

---

## 📦 Що робить авто-скрипт

`scripts/prepare-deploy.mjs` виконує повну підготовку:

| # | Дія | Навіщо |
|---|-----|--------|
| 1 | Перевіряє `dist/` | захист від порожньої збірки |
| 2 | Виправляє абсолютні шляхи → відносні | сайт працює у **підпапках** та на будь-якому домені |
| 3 | Додає `<base href="./">` | коректні посилання |
| 4 | Створює `404.html` | SPA-фолбек (GitHub Pages, Nginx) |
| 5 | Створює `sw.js` | **офлайн-режим** та кешування (PWA) |
| 6 | Додає відсутні мета-теги | SEO, Open Graph, тема |
| 7 | Підставляє домен у `robots.txt` / `sitemap.xml` | правильна індексація |
| 8 | Додає `security.txt` | стандарт безпеки RFC 9116 |
| 9 | Створює `deploy.zip` | готовий архів для FTP |
| 10 | Виводить підсумок | контроль розміру та файлів |

### Прапорці скрипта

```bash
node scripts/prepare-deploy.mjs --url=https://antique.dp.ua   # ваш домен
node scripts/prepare-deploy.mjs --base=/shop/                 # деплой у підпапку
node scripts/prepare-deploy.mjs --no-zip                      # без архіву
```

---

## 🌐 Варіант A · Звичайний хостинг (cPanel, ISPmanager, FTP)

### Ручне завантаження
1. Виконайте `npm run build && node scripts/prepare-deploy.mjs`
2. Відкрийте **файл-менеджер** хостингу або FTP-клієнт (FileZilla)
3. Завантажте **весь вміст папки `dist/`** у `public_html/`
4. Готово ✅

> ⚠️ Завантажуйте **вміст** `dist/`, а не саму папку. `index.html` має лежати в корені `public_html/`.

### Автоматичне завантаження (Git → FTP)
У файлі `.github/workflows/deploy-ftp.yml` уже є готовий workflow.

Додайте **Secrets** у GitHub:
`Settings → Secrets and variables → Actions → New repository secret`

| Secret | Приклад |
|--------|---------|
| `FTP_SERVER` | `ftp.antique.dp.ua` |
| `FTP_USERNAME` | `user_antique` |
| `FTP_PASSWORD` | `********` |
| `FTP_SERVER_DIR` | `public_html/` |

Після `git push` сайт опублікується автоматично.

### Для Nginx-хостингу
```nginx
server {
    listen 80;
    server_name antique.dp.ua;
    root /var/www/antique/dist;
    index index.html;

    # Gzip
    gzip on;
    gzip_types text/html text/css application/javascript image/svg+xml;

    # Кеш зображень
    location ~* \.(jpg|jpeg|png|svg|webp|ico)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # HTML завжди свіжий
    location = /index.html {
        add_header Cache-Control "no-cache, must-revalidate";
    }

    # SPA-фолбек
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## ☁️ Варіант B · Netlify

Конфіг **`netlify.toml`** уже в корені проекту.

1. Зайдіть на [netlify.com](https://netlify.com) → **Add new site → Import existing project**
2. Оберіть Git-репозиторій
3. Налаштування підтягнуться автоматично:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. **Deploy**

Або через CLI:
```bash
npm i -g netlify-cli
npm run build && node scripts/prepare-deploy.mjs --no-zip
netlify deploy --prod --dir=dist
```

---

## ▲ Варіант C · Vercel

Конфіг **`vercel.json`** уже в корені.

```bash
npm i -g vercel
vercel --prod
```

Або через [vercel.com](https://vercel.com) → **Add New Project → Import** — налаштування застосуються автоматично.

---

## 🐙 Варіант D · GitHub Pages

Workflow **`.github/workflows/deploy-pages.yml`** уже готовий.

1. `Settings → Pages → Source: GitHub Actions`
2. `git push` у гілку `main`
3. Сайт буде на `https://username.github.io/repo/`

> Скрипт автоматично створює `404.html` та відносні шляхи, тому сайт коректно працює навіть у підпапці `/repo/`.

---

## 🐳 Варіант E · Docker / VPS

```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci || npm install
COPY . .
RUN npm run build && node scripts/prepare-deploy.mjs --no-zip

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

```bash
docker build -t antique-dnipro .
docker run -p 80:80 antique-dnipro
```

---

## 🔍 Після публікації — чеклист

- [ ] Сайт відкривається за вашим доменом
- [ ] Форма заявки працює (заявка з'являється в `#admin`)
- [ ] Адмінка доступна: `вашдомен.com/#admin` (пароль `admin`)
- [ ] **Змініть пароль адмінки** → `#admin` → Налаштування → Безпека
- [ ] Зображення завантажуються (перевірте Hero та категорії)
- [ ] Мобільна версія коректна
- [ ] `robots.txt` відкривається: `домен/robots.txt`
- [ ] `sitemap.xml` відкривається: `домен/sitemap.xml`
- [ ] Додайте сайт у [Google Search Console](https://search.google.com/search-console)
- [ ] Замініть `example` URL у `public/robots.txt` та `public/sitemap.xml` на реальний домен

---

## 🔐 Важливо про безпеку

Панель власника зберігає дані в `localStorage` браузера. Це означає:

| Обмеження | Рішення |
|-----------|---------|
| Заявки видно лише на цьому пристрої | підключити backend (Supabase / Firebase / API) |
| Пароль у відкритому вигляді в JS | перенести авторизацію на сервер |
| Немає синхронізації між пристроями | використати Supabase (безкоштовний тариф) |

> Для прийому заявок з будь-яких пристроїв рекомендується безкоштовний [Supabase](https://supabase.com) — досить однієї таблиці `requests`.

---

## 📁 Файли деплою в проекті

```
├── scripts/
│   └── prepare-deploy.mjs        ← головний авто-скрипт
├── .github/workflows/
│   ├── deploy-pages.yml          ← авто-деплой на GitHub Pages
│   └── deploy-ftp.yml            ← авто-деплой на FTP-хостинг
├── public/
│   ├── .htaccess                 ← конфіг Apache (кеш, gzip, SPA)
│   ├── robots.txt                ← індексація
│   ├── sitemap.xml               ← карта сайту
│   ├── site.webmanifest          ← PWA-маніфест
│   └── favicon.svg               ← іконка
├── netlify.toml                  ← конфіг Netlify
├── vercel.json                   ← конфіг Vercel
└── DEPLOY.md                     ← цей файл
```
