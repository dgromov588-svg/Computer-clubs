#!/usr/bin/env bash
# ============================================================
#  Автоматичний деплой · Скупка антикваріату Дніпро
# ============================================================
#  Використання:
#     ./deploy.sh                       # збірка + підготовка + архів
#     ./deploy.sh --url=https://antique.dp.ua
#     DEPLOY_SSH=user@server DEPLOY_PATH=/var/www/html ./deploy.sh --rsync
# ============================================================
set -e

FLAGS="$@"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🏛  Скупка антикваріату · деплой"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 1. Залежності
if [ ! -d "node_modules" ]; then
  echo "▸ Встановлення залежностей..."
  npm ci --no-audit --no-fund 2>/dev/null || npm install --no-audit --no-fund
fi

# 2. Перевірка типів
echo "▸ Перевірка TypeScript..."
npx tsc --noEmit || echo "  (знайдено попередження типів — продовжуємо)"

# 3. Збірка
echo "▸ Збірка проекту..."
npm run build

# 4. Автоналаштування
echo "▸ Автоналаштування деплою..."
node scripts/prepare-deploy.mjs $FLAGS

# 5. Опціональне завантаження на сервер
if [[ "$FLAGS" == *"--rsync"* ]]; then
  if [ -z "$DEPLOY_SSH" ] || [ -z "$DEPLOY_PATH" ]; then
    echo ""
    echo "  Для rsync вкажіть змінні:"
    echo "    DEPLOY_SSH=user@server DEPLOY_PATH=/var/www/html ./deploy.sh --rsync"
    exit 1
  fi
  echo "▸ Завантаження на ${DEPLOY_SSH}:${DEPLOY_PATH} ..."
  rsync -avz --delete dist/ "${DEPLOY_SSH}:${DEPLOY_PATH}/"
  echo "✓ Сайт опубліковано!"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✓ Готово. Вміст папки dist/ завантажте у public_html/"
echo "  deploy.zip — архів для ручного завантаження"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
