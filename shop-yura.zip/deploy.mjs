#!/usr/bin/env node
/**
 * ==================================================================
 *  АВТОЗАЛИВКА САЙТУ «Салон АнтикварЪ» НА CITYHOST — ОДНІЄЮ КОМАНДОЮ
 * ==================================================================
 *
 *      node deploy.mjs
 *
 *  Працює однаково на Windows / macOS / Linux (потрібен лише Node.js 18+).
 *  Окремі програми ssh/scp не потрібні.
 *
 *  Що відбувається:
 *    1. Збірка сайту (npm run build + підготовка до хостингу)
 *    2. Підключення до сервера (SSH-ключ або пароль — запитується 1 раз)
 *    3. Пошук папки сайту (якщо їх кілька — запропонує вибрати і ЗАПАМʼЯТАЄ)
 *    4. Завантаження файлів
 *    5. Резервна копія старої версії (~/site-backups, 5 останніх) і заміна
 *    6. Перевірка, що сайт відкривається
 *
 *  Параметри (необовʼязкові):
 *    --url=https://домен.ua   адреса сайту (SEO + перевірка після заливки)
 *    --path=/home/.../www/д   папка сайту на сервері
 *    --clean                  видалити старі файли на сервері перед заливкою
 *    --skip-build             не збирати, залити наявний dist/
 *    --yes                    без запитань (для автоматизації)
 *
 *  Налаштування зберігаються у .env.deploy (не потрапляє в git).
 * ==================================================================
 */

import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import { execSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import os from 'node:os'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const DIST = path.join(ROOT, 'dist')
const ENV_FILE = path.join(ROOT, '.env.deploy')
process.chdir(ROOT)

// ---------- Вивід ----------
const c = {
  b: (s) => `\x1b[1m${s}\x1b[0m`,
  g: (s) => `\x1b[32m${s}\x1b[0m`,
  y: (s) => `\x1b[33m${s}\x1b[0m`,
  r: (s) => `\x1b[31m${s}\x1b[0m`,
  d: (s) => `\x1b[2m${s}\x1b[0m`,
  gold: (s) => `\x1b[38;5;178m${s}\x1b[0m`,
}
const step = (n, t) => console.log(`\n${c.gold(`[${n}/6]`)} ${c.b(t)}`)
const ok = (t) => console.log(`  ${c.g('✓')} ${t}`)
const info = (t) => console.log(`  ${c.d(t)}`)
const warn = (t) => console.log(`  ${c.y('!')} ${t}`)
const fail = (t, hints = []) => {
  console.log(`\n  ${c.r('✗')} ${c.b(t)}`)
  for (const h of hints) console.log(`    ${h}`)
  console.log('')
  process.exit(1)
}

// ---------- Аргументи ----------
const args = process.argv.slice(2)
const flag = (n) => args.includes(`--${n}`)
const opt = (n) => {
  const a = args.find((x) => x.startsWith(`--${n}=`))
  return a ? a.slice(n.length + 3) : undefined
}
if (flag('help') || flag('h')) {
  const src = fs.readFileSync(fileURLToPath(import.meta.url), 'utf8')
  console.log(src.split('\n').slice(2, 30).map((l) => l.replace(/^ \*\s?/, '')).join('\n'))
  process.exit(0)
}

// ---------- .env.deploy ----------
function readEnv() {
  if (!fs.existsSync(ENV_FILE)) return {}
  const out = {}
  for (const line of fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/)
    if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '')
  }
  return out
}
function saveEnv(key, value) {
  let text = fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, 'utf8') : ''
  const re = new RegExp(`^${key}=.*$`, 'm')
  text = re.test(text) ? text.replace(re, `${key}=${value}`) : `${text.trimEnd()}\n${key}=${value}\n`.trimStart()
  fs.writeFileSync(ENV_FILE, text)
}

const env = { ...readEnv(), ...process.env }
// Секрет приймача з .env.deploy → у збірку (щоб і заливка з компʼютера не прибирала deploy-hook.php)
if (env.DEPLOY_HOOK_SECRET) process.env.DEPLOY_HOOK_SECRET = env.DEPLOY_HOOK_SECRET
const CFG = {
  host: env.DEPLOY_HOST || 'amarok.cityhost.com.ua',
  user: env.DEPLOY_USER || 'ch9ca38181',
  port: Number(env.DEPLOY_PORT || 22),
  path: opt('path') || env.DEPLOY_PATH || '',
  url: (opt('url') || env.DEPLOY_URL || '').replace(/\/+$/, ''),
  password: env.DEPLOY_PASSWORD || '',
  key: env.DEPLOY_KEY || '',
  clean: flag('clean'),
  skipBuild: flag('skip-build'),
  yes: flag('yes') || !process.stdin.isTTY,
}

// ---------- Ввід ----------
function ask(q) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  return new Promise((res) => rl.question(q, (a) => (rl.close(), res(a.trim()))))
}
function askHidden(q) {
  return new Promise((res) => {
    const stdin = process.stdin
    process.stdout.write(q)
    if (!stdin.isTTY) {
      const rl = readline.createInterface({ input: stdin })
      rl.once('line', (l) => (rl.close(), res(l)))
      return
    }
    let s = ''
    stdin.setRawMode(true)
    stdin.resume()
    stdin.setEncoding('utf8')
    const onData = (chunk) => {
      for (const ch of chunk) {
        if (ch === '\r' || ch === '\n') {
          stdin.setRawMode(false)
          stdin.pause()
          stdin.off('data', onData)
          process.stdout.write('\n')
          return res(s)
        }
        if (ch === '\u0003') {
          process.stdout.write('\n')
          process.exit(130)
        }
        if (ch === '\u007f' || ch === '\b') {
          if (s) {
            s = s.slice(0, -1)
            process.stdout.write('\b \b')
          }
          continue
        }
        s += ch
        process.stdout.write('•')
      }
    }
    stdin.on('data', onData)
  })
}

const run = (cmd) => execSync(cmd, { stdio: 'inherit', shell: true, cwd: ROOT })

// Адресу, передану через --url, запамʼятовуємо
if (opt('url') && CFG.url !== env.DEPLOY_URL) saveEnv('DEPLOY_URL', CFG.url)

// ==================================================================
console.log('')
console.log(c.gold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'))
console.log(`  ${c.b('Салон «АнтикварЪ»')} → ${c.b('CityHost')}`)
console.log(`  ${c.d(`${CFG.user}@${CFG.host}`)}`)
console.log(c.gold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'))

const [major] = process.versions.node.split('.').map(Number)
if (major < 18) fail(`Потрібен Node.js 18 або новіший (у вас ${process.versions.node})`, ['Завантажте: https://nodejs.org'])

// ---------- 1. Збірка ----------
step(1, 'Збірка сайту')
if (!fs.existsSync(path.join(ROOT, 'node_modules', 'node-ssh'))) {
  info('Встановлення залежностей...')
  run('npm install --no-audit --no-fund')
}
if (CFG.skipBuild) {
  info('Пропущено (--skip-build)')
} else {
  try {
    run('npm run build')
    run(`node scripts/prepare-deploy.mjs --no-zip${CFG.url ? ` --url=${CFG.url}` : ''}`)
  } catch {
    fail('Збірка не вдалася — дивіться повідомлення вище')
  }
}
if (!fs.existsSync(path.join(DIST, 'index.html'))) fail('dist/index.html не знайдено')

const files = []
;(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name)
    e.isDirectory() ? walk(p) : files.push(p)
  }
})(DIST)
const totalKB = Math.round(files.reduce((a, f) => a + fs.statSync(f).size, 0) / 1024)
ok(`Готово: ${files.length} файлів, ${totalKB} KB`)

// ---------- 2. Підключення ----------
step(2, 'Підключення до сервера')
const mod = await import('node-ssh')
const NodeSSH = mod.NodeSSH || mod.default?.NodeSSH
const ssh = new NodeSSH()

const base = { host: CFG.host, port: CFG.port, username: CFG.user, readyTimeout: 25000, tryKeyboard: true }

function explain(e) {
  const m = String(e?.message || e)
  if (/authentication/i.test(m)) return 'auth'
  if (/ETIMEDOUT|ECONNREFUSED|ECONNRESET|Timed out|EHOSTUNREACH|handshake/i.test(m)) return 'network'
  if (/ENOTFOUND|EAI_AGAIN/i.test(m)) return 'dns'
  return m
}
const IP_HINTS = [
  'Найчастіше CityHost блокує SSH з незнайомих IP. Відкрийте:',
  `  ${c.b('Панель CityHost → Хостинг 2.0 → Керування → SSH → Дозволені IP → Додати IP')}`,
  '  (вимкніть VPN і натисніть «додати поточний IP», потім запустіть знову)',
]

let connected = false
// 2а. SSH-ключ
const keyCandidates = [CFG.key, ...['id_ed25519', 'id_rsa', 'id_ecdsa'].map((k) => path.join(os.homedir(), '.ssh', k))]
  .filter((k) => k && fs.existsSync(k))
for (const key of keyCandidates) {
  try {
    await ssh.connect({ ...base, privateKeyPath: key })
    ok(`Вхід за SSH-ключем (${path.basename(key)})`)
    connected = true
    break
  } catch (e) {
    const why = explain(e)
    if (why === 'network') fail(`Сервер ${CFG.host} не відповідає`, IP_HINTS)
    if (why === 'dns') fail(`Не вдається знайти сервер ${CFG.host}`, ['Перевірте інтернет-зʼєднання'])
  }
}
// 2б. Пароль
for (let attempt = 1; !connected && attempt <= 3; attempt++) {
  let password = CFG.password
  if (!password || attempt > 1) {
    if (CFG.yes && !process.stdin.isTTY && attempt > 1) break
    password = await askHidden(`  Пароль SSH для ${c.b(CFG.user)}: `)
  }
  try {
    await ssh.connect({ ...base, password })
    ok('Підключено')
    connected = true
  } catch (e) {
    const why = explain(e)
    if (why === 'network') fail(`Сервер ${CFG.host} не відповідає`, IP_HINTS)
    if (why === 'dns') fail(`Не вдається знайти сервер ${CFG.host}`, ['Перевірте інтернет-зʼєднання'])
    if (why === 'auth') warn(`Невірний пароль (спроба ${attempt} з 3)`)
    else fail(`Помилка підключення: ${why}`)
  }
}
if (!connected) fail('Не вдалося увійти на сервер', ['Перевірте пароль у панелі CityHost → Хостинг 2.0 → Керування → SSH', ...IP_HINTS])

const sh = async (cmd) => {
  const r = await ssh.execCommand(cmd)
  return { out: r.stdout.trim(), err: r.stderr.trim(), code: r.code }
}
const HOME = (await sh('printf %s "$HOME"')).out || `/home/${CFG.user}`

// ---------- 3. Папка сайту ----------
step(3, 'Папка сайту на сервері')
let target = CFG.path
if (target) {
  ok(target)
} else {
  const { out } = await sh(
    'for d in "$HOME"/www/*/ "$HOME"/*/www/ "$HOME"/public_html/; do [ -d "$d" ] && echo "${d%/}"; done | sort -u',
  )
  const dirs = out.split('\n').filter(Boolean)
  if (dirs.length === 1) {
    target = dirs[0]
    ok(`Знайдено: ${target}`)
  } else if (dirs.length > 1 && !CFG.yes) {
    console.log('  Знайдено кілька папок сайтів:')
    dirs.forEach((d, i) => console.log(`    ${c.gold(String(i + 1))}) ${d}`))
    const pick = Number(await ask(`  Оберіть номер [1-${dirs.length}]: `))
    if (!(pick >= 1 && pick <= dirs.length)) fail('Невірний вибір')
    target = dirs[pick - 1]
  } else {
    const { out: ls } = await sh('ls -la "$HOME"')
    fail(dirs.length ? 'Знайдено кілька папок — вкажіть потрібну' : 'Папку сайту не знайдено', [
      'Вміст домашньої папки на сервері:',
      ...ls.split('\n').map((l) => c.d('  ' + l)),
      '',
      `Додайте сайт у панелі: ${c.b('Хостинг 2.0 → Сайти → Додати сайт')}, або вкажіть папку:`,
      `  ${c.b(`node deploy.mjs --path=${HOME}/www/ваш-домен.ua`)}`,
    ])
  }
  if (target !== env.DEPLOY_PATH) {
    saveEnv('DEPLOY_PATH', target)
    info('Запамʼятовано в .env.deploy — наступного разу питати не буду')
  }
}
if (!target.startsWith(HOME + '/')) fail(`Папка має бути всередині ${HOME}`)

// Домен з назви папки — для перевірки після заливки
if (!CFG.url) {
  const m = target.match(/\/www\/([^/]+\.[a-z]{2,})$/i) || target.match(/\/([^/]+\.[a-z]{2,})\/www$/i)
  if (m) CFG.url = `https://${m[1]}`
}

// ---------- 4. Завантаження ----------
step(4, 'Завантаження файлів')
const UPLOAD = `${HOME}/.antikvar-upload`
await sh(`rm -rf "${UPLOAD}" && mkdir -p "${UPLOAD}"`)
let done = 0
const failed = []
const okUpload = await ssh.putDirectory(DIST, UPLOAD, {
  recursive: true,
  concurrency: 4,
  validate: (p) => !path.basename(p).startsWith('.DS_Store'),
  tick: (local, _remote, error) => {
    done++
    if (error) failed.push(path.relative(DIST, local))
    process.stdout.write(`\r  ${c.d(`${done}/${files.length}`)} ${path.relative(DIST, local).slice(0, 50).padEnd(50)}`)
  },
})
process.stdout.write('\r' + ' '.repeat(70) + '\r')
if (!okUpload || failed.length) fail('Не всі файли завантажились', failed.map((f) => '• ' + f))
await ssh.putFile(path.join(ROOT, 'scripts', 'remote-install.sh'), `${HOME}/remote-install.sh`)
ok(`Завантажено ${files.length} файлів`)

// ---------- 5. Встановлення ----------
step(5, 'Резервна копія і заміна сайту')
const inst = await sh(`sh "${HOME}/remote-install.sh" '${target}' '${CFG.clean ? 'clean' : ''}'`)
for (const l of inst.out.split('\n').filter(Boolean)) info(l.replace(/^\s*[✓▸]\s*/, ''))
if (inst.code !== 0) fail('Встановлення на сервері не вдалося', inst.err.split('\n'))
ssh.dispose()
ok('Сайт оновлено')

// ---------- 6. Перевірка ----------
step(6, 'Перевірка')
if (CFG.url) {
  try {
    const r = await fetch(`${CFG.url}/?v=${Date.now()}`, { redirect: 'follow', signal: AbortSignal.timeout(15000) })
    const html = await r.text()
    if (r.ok && html.includes('АнтикварЪ')) ok(`${CFG.url} відкривається (HTTP ${r.status})`)
    else warn(`${CFG.url} відповідає HTTP ${r.status} — перевірте, що домен привʼязаний до цієї папки`)
  } catch {
    warn(`${CFG.url} поки не відкривається — можливо, домен ще не налаштовано (DNS до 24 год)`)
  }
} else {
  info('Адресу сайту не вказано — додайте: node deploy.mjs --url=https://ваш-домен.ua')
}

console.log('')
console.log(c.gold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'))
console.log(`  ${c.g('✓')} ${c.b('Готово!')} ${CFG.url ? `Відкрийте ${c.b(CFG.url)}` : ''} ${c.d('(Ctrl+F5)')}`)
console.log(c.gold('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'))
console.log('')
