#!/usr/bin/env bash
# Сумісність: тепер уся логіка в deploy.mjs (Windows / macOS / Linux).
cd "$(dirname "$0")"
exec node deploy.mjs "$@"
