import { pgTable, serial, text, integer, timestamp, boolean } from 'drizzle-orm/pg-core';

export const clients = pgTable('club_clients', {
  id: serial('id').primaryKey(), name: text('name').notNull(), nickname: text('nickname').notNull(),
  phone: text('phone').notNull(), email: text('email').notNull().default(''), balance: integer('balance').notNull().default(0),
  wins: integer('wins').notNull().default(0), losses: integer('losses').notNull().default(0), createdAt: timestamp('created_at').defaultNow().notNull(),
});
export const computers = pgTable('club_computers', {
  id: integer('id').primaryKey(), name: text('name').notNull(), zone: text('zone').notNull(),
  status: text('status').notNull().default('free'), ip: text('ip').notNull(), specs: text('specs').notNull(),
});
export const operators = pgTable('club_operators', {
  id: serial('id').primaryKey(), name: text('name').notNull(), role: text('role').notNull(), active: boolean('active').notNull().default(false),
});
export const visits = pgTable('club_visits', {
  id: serial('id').primaryKey(), clientId: integer('client_id').notNull().references(() => clients.id),
  computerId: integer('computer_id').notNull().references(() => computers.id), operatorId: integer('operator_id').notNull().references(() => operators.id),
  startedAt: timestamp('started_at').notNull(), endsAt: timestamp('ends_at').notNull(), finishedAt: timestamp('finished_at'),
  amount: integer('amount').notNull(), wins: integer('wins').notNull().default(0), losses: integer('losses').notNull().default(0),
});
export const events = pgTable('club_events', {
  id: serial('id').primaryKey(), type: text('type').notNull(), title: text('title').notNull(), detail: text('detail').notNull(), createdAt: timestamp('created_at').defaultNow().notNull(),
});
export const cameras = pgTable('club_cameras', {
  id: serial('id').primaryKey(), name: text('name').notNull(), location: text('location').notNull(), url: text('url').notNull().default(''), kind: text('kind').notNull().default('mjpeg'),
});
export const checks = pgTable('club_checks', {
  id: serial('id').primaryKey(), computerId: integer('computer_id').notNull().references(() => computers.id),
  clientId: integer('client_id').references(() => clients.id), operatorId: integer('operator_id').notNull().references(() => operators.id),
  game: text('game').notNull(), quantity: integer('quantity').notNull(), unitPrice: integer('unit_price').notNull(), amount: integer('amount').notNull(),
  status: text('status').notNull().default('open'), createdAt: timestamp('created_at').defaultNow().notNull(), paidAt: timestamp('paid_at'),
});
