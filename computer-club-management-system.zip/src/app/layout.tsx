import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Вип Club — система управления игровым залом",
  description: "Чеки на игру, клиенты, сессии, терминалы и видеонаблюдение игрового зала в одной системе.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
