import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { clients, computers, operators, visits, events, cameras, checks } from '@/db/schema';
import { eq, desc, sql, and, isNull } from 'drizzle-orm';
import { makeDemo } from '@/lib/demo';
export const dynamic = 'force-dynamic';

async function seed() {
  await db.transaction(async tx => {
    await tx.execute(sql`select pg_advisory_xact_lock(768410)`);
    if ((await tx.select().from(computers).limit(1)).length) return;
    const demo = makeDemo();
    await tx.insert(clients).values(demo.clients.map(c => ({...c, createdAt: c.createdAt ? new Date(c.createdAt) : new Date()})));
    await tx.insert(computers).values(demo.computers);
    await tx.insert(operators).values(demo.operators);
    await tx.insert(visits).values(demo.visits.map(v => ({...v, startedAt:new Date(v.startedAt),endsAt:new Date(v.endsAt),finishedAt:v.finishedAt ? new Date(v.finishedAt) : null})));
    await tx.insert(cameras).values(demo.cameras);
    await tx.insert(checks).values(demo.checks.map(c => ({...c,createdAt:new Date(c.createdAt),paidAt:c.paidAt ? new Date(c.paidAt) : null})));
    await tx.insert(events).values(demo.events.map(e => ({...e,createdAt:new Date(e.createdAt)})));
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_clients','id'), (select max(id) from club_clients))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_operators','id'), (select max(id) from club_operators))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_visits','id'), (select max(id) from club_visits))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_cameras','id'), (select max(id) from club_cameras))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_checks','id'), (select max(id) from club_checks))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_events','id'), (select max(id) from club_events))`);
  });
}
export async function GET() {
  try {
    await seed();
    const [c, p, o, v, chk, e, cam] = await Promise.all([db.select().from(clients).orderBy(clients.id), db.select().from(computers).orderBy(computers.id), db.select().from(operators), db.select().from(visits).orderBy(desc(visits.startedAt)), db.select().from(checks).orderBy(desc(checks.createdAt)).limit(300), db.select().from(events).orderBy(desc(events.createdAt)).limit(100), db.select().from(cameras).orderBy(cameras.id)]);
    return NextResponse.json({clients:c,computers:p,operators:o,visits:v,checks:chk,events:e,cameras:cam,agentConnected:Boolean(process.env.LOCAL_AGENT_URL && process.env.LOCAL_AGENT_TOKEN)});
  } catch (err) { console.error(err); return NextResponse.json({error:'Не удалось подключиться к базе данных'}, {status:500}); }
}
export async function POST(req: NextRequest) {
  if (req.headers.get('sec-fetch-site') === 'cross-site') return NextResponse.json({error:'Запрос запрещён'}, {status:403});
  try {
    const body = await req.json();
    const action = body.action;
    if (action === 'client') {
      const name = String(body.name || '').trim().slice(0,100), phone = String(body.phone || '').trim().slice(0,30), nickname = String(body.nickname || '').trim().slice(0,40), email = String(body.email || '').trim().slice(0,120);
      if (name.length < 2 || phone.replace(/\D/g,'').length < 10 || !nickname) throw new Error('Укажите имя, никнейм и корректный телефон');
      const values = {name,phone,nickname,email};
      if (body.id) await db.update(clients).set(values).where(eq(clients.id,Number(body.id)));
      else await db.transaction(async tx => { await tx.insert(clients).values(values); await tx.insert(events).values({type:'client',title:'Новый клиент',detail:`${name} · Регистрация в клубе`}); });
    } else if (action === 'session') {
      const computerId = Number(body.computerId), clientId = Number(body.clientId), minutes = Number(body.minutes);
      if (![60,120,180,300].includes(minutes)) throw new Error('Выберите длительность сессии');
      await db.transaction(async tx => {
        const pc = (await tx.select().from(computers).where(eq(computers.id,computerId)).for('update'))[0];
        if (!pc || pc.status !== 'free') throw new Error('Компьютер уже занят или недоступен');
        const client = (await tx.select().from(clients).where(eq(clients.id,clientId)).for('update'))[0];
        if (!client) throw new Error('Клиент не найден');
        if ((await tx.select().from(visits).where(and(eq(visits.clientId,clientId),isNull(visits.finishedAt)))).length) throw new Error('У клиента уже есть активная сессия');
        const amount = minutes / 60 * (pc.zone === 'VIP-зал' ? 400 : 250);
        if (client.balance < amount) throw new Error('Недостаточно средств на балансе клиента');
        await tx.update(clients).set({balance:sql`${clients.balance} - ${amount}`}).where(eq(clients.id,clientId));
        await tx.insert(visits).values({clientId,computerId,operatorId:1,startedAt:new Date(),endsAt:new Date(Date.now()+minutes*60000),amount});
        await tx.update(computers).set({status:'busy'}).where(eq(computers.id,computerId));
        await tx.insert(events).values({type:'session',title:'Новая игровая сессия',detail:`${pc.name} · ${client.name} · ${minutes} мин`});
      });
    } else if (action === 'endSession') {
      const wins = Number(body.wins || 0), losses = Number(body.losses || 0);
      if (![wins,losses].every(n => Number.isInteger(n) && n >= 0 && n <= 100)) throw new Error('Результаты должны быть от 0 до 100');
      await db.transaction(async tx => {
        const v = (await tx.select().from(visits).where(eq(visits.id,Number(body.id))).for('update'))[0];
        if (!v || v.finishedAt) throw new Error('Сессия уже завершена');
        await tx.update(visits).set({finishedAt:new Date(),wins,losses}).where(eq(visits.id,v.id));
        await tx.update(clients).set({wins:sql`${clients.wins}+${wins}`,losses:sql`${clients.losses}+${losses}`}).where(eq(clients.id,v.clientId));
        await tx.update(computers).set({status:'free'}).where(eq(computers.id,v.computerId));
        await tx.insert(events).values({type:'session',title:'Сессия завершена',detail:`PC-${String(v.computerId).padStart(2,'0')} · Победы: ${wins} · Поражения: ${losses}`});
      });
    } else if (action === 'topup') {
      const amount = Number(body.amount);
      if (!Number.isInteger(amount) || amount < 1 || amount > 100000) throw new Error('Сумма должна быть от 1 до 100 000 ₽');
      await db.transaction(async tx => {
        const c = (await tx.update(clients).set({balance:sql`${clients.balance}+${amount}`}).where(eq(clients.id,Number(body.id))).returning())[0];
        if (!c) throw new Error('Клиент не найден');
        await tx.insert(events).values({type:'payment',title:'Пополнение баланса',detail:`${c.name} · +${amount} ₽ (учёт наличных)`});
      });
    } else if (action === 'check') {
      const computerId = Number(body.computerId), quantity = Number(body.quantity), unitPrice = Number(body.unitPrice), operatorId = Number(body.operatorId) || 1;
      const game = String(body.game || '').trim().slice(0, 40);
      const clientId = body.clientId ? Number(body.clientId) : null;
      if (game.length < 2) throw new Error('Укажите игру: Супер Matic, Чемпионы StarLine или другое название');
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 200) throw new Error('Количество игр: от 1 до 200');
      if (!Number.isInteger(unitPrice) || unitPrice < 10 || unitPrice > 10000) throw new Error('Цена за игру: от 10 до 10 000 ₽');
      const amount = quantity * unitPrice;
      await db.transaction(async tx => {
        const pc = (await tx.select().from(computers).where(eq(computers.id,computerId)))[0];
        if (!pc) throw new Error('Терминал с таким номером не найден');
        if (clientId && !(await tx.select().from(clients).where(eq(clients.id,clientId)))[0]) throw new Error('Клиент не найден');
        const operator = (await tx.select().from(operators).where(eq(operators.id,operatorId)))[0];
        await tx.insert(checks).values({computerId,clientId,operatorId,game,quantity,unitPrice,amount});
        await tx.insert(events).values({type:'check',title:'Чек на игру пробит',detail:`${pc.name} · ${game} · ${quantity} игр · ${amount} ₽ · ${operator?.name ?? 'оператор'}`});
      });
    } else if (action === 'checkStatus') {
      const status = body.status;
      if (!['open','paid','void'].includes(status)) throw new Error('Некорректный статус чека');
      await db.transaction(async tx => {
        const chk = (await tx.select().from(checks).where(eq(checks.id,Number(body.id))).for('update'))[0];
        if (!chk) throw new Error('Чек не найден');
        if (chk.status === 'void') throw new Error('Аннулированный чек нельзя изменить');
        if (chk.status === 'paid' && status !== 'paid') throw new Error('Оплаченный чек нельзя вернуть в оплату. Оформите возврат отдельно.');
        await tx.update(checks).set({status,paidAt:status === 'paid' ? new Date() : null}).where(eq(checks.id,chk.id));
        await tx.insert(events).values({type:'check',title:status === 'paid' ? 'Чек оплачен' : 'Чек аннулирован',detail:`${chk.game} · ${chk.quantity} игр · ${chk.amount} ₽ · PC-${String(chk.computerId).padStart(2,'0')}`});
      });
    } else if (action === 'camera') {
      const url = String(body.url || '').trim();
      if (url && !/^https?:\/\//i.test(url)) throw new Error('Нужна HTTP(S)-ссылка на MJPEG или браузерный видеопоток. RTSP подключается через шлюз.');
      if (!['mjpeg','video'].includes(body.kind)) throw new Error('Неизвестный тип потока');
      await db.update(cameras).set({url,kind:body.kind}).where(eq(cameras.id,Number(body.id)));
    } else if (action === 'control') {
      const pc = (await db.select().from(computers).where(eq(computers.id,Number(body.id))))[0];
      if (!pc || !['restart','shutdown','wake','lock','unlock'].includes(body.command)) throw new Error('Некорректная команда');
      if (!process.env.LOCAL_AGENT_URL || !process.env.LOCAL_AGENT_TOKEN) return NextResponse.json({error:'Локальный агент не подключён. Настройте LOCAL_AGENT_URL и LOCAL_AGENT_TOKEN на сервере. Команда не отправлена.'},{status:503});
      const response = await fetch(`${process.env.LOCAL_AGENT_URL.replace(/\/$/,'')}/commands`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${process.env.LOCAL_AGENT_TOKEN}`},body:JSON.stringify({computerId:pc.id,ip:pc.ip,command:body.command}),signal:AbortSignal.timeout(8000)});
      if (!response.ok) throw new Error('Агент отклонил команду. Проверьте журнал агента.');
      await db.insert(events).values({type:'system',title:'Команда принята агентом',detail:`${pc.name} · ${body.command}. Выполнение проверяется на устройстве.`});
    } else throw new Error('Неизвестное действие');
    return NextResponse.json({ok:true});
  } catch (err) { return NextResponse.json({error:err instanceof Error ? err.message : 'Ошибка сохранения'},{status:400}); }
}
