import { GAME_CATALOG } from './games';
export type Client = { id: number; name: string; nickname: string; phone: string; email: string; balance: number; wins: number; losses: number; createdAt?: string };
export type Computer = { id: number; name: string; zone: string; status: string; ip: string; specs: string };
export type Operator = { id: number; name: string; role: string; active: boolean };
export type Visit = { id: number; clientId: number; computerId: number; operatorId: number; startedAt: string; endsAt: string; finishedAt: string | null; amount: number; wins: number; losses: number };
export type ClubEvent = { id: number; type: string; title: string; detail: string; createdAt: string };
export type Camera = { id: number; name: string; location: string; url: string; kind: string };
export type ClubCheck = { id: number; computerId: number; clientId: number | null; operatorId: number; game: string; quantity: number; unitPrice: number; amount: number; status: string; createdAt: string; paidAt: string | null };
export type ClubData = { clients: Client[]; computers: Computer[]; operators: Operator[]; visits: Visit[]; checks: ClubCheck[]; events: ClubEvent[]; cameras: Camera[]; agentConnected: boolean };
export const demoClients: Client[] = [
  { id: 1, name: 'Александр Петров', nickname: 's1mple_fan', phone: '+7 (999) 124-56-78', email: 'alex.petrov@example.com', balance: 1250, wins: 86, losses: 42 },
  { id: 2, name: 'Дмитрий Волков', nickname: 'D1m0n', phone: '+7 (999) 235-67-89', email: '', balance: 850, wins: 64, losses: 38 },
  { id: 3, name: 'Максим Иванов', nickname: 'maxpower', phone: '+7 (999) 346-78-90', email: '', balance: 2300, wins: 112, losses: 56 },
  { id: 4, name: 'Артём Соколов', nickname: 'art1k', phone: '+7 (999) 457-89-01', email: '', balance: 400, wins: 35, losses: 24 },
  { id: 5, name: 'Никита Смирнов', nickname: 'N1kita', phone: '+7 (999) 568-90-12', email: '', balance: 1600, wins: 73, losses: 31 },
  { id: 6, name: 'Анна Козлова', nickname: 'anomaly', phone: '+7 (999) 679-01-23', email: '', balance: 950, wins: 91, losses: 44 },
  { id: 7, name: 'Илья Морозов', nickname: 'frost', phone: '+7 (999) 780-12-34', email: '', balance: 500, wins: 48, losses: 29 },
  { id: 8, name: 'Егор Новиков', nickname: 'egor_gg', phone: '+7 (999) 891-23-45', email: '', balance: 3200, wins: 127, losses: 62 },
  { id: 9, name: 'Кирилл Орлов', nickname: 'eagle', phone: '+7 (999) 902-34-56', email: '', balance: 700, wins: 59, losses: 37 },
  { id: 10, name: 'София Лебедева', nickname: 'sophie', phone: '+7 (999) 013-45-67', email: '', balance: 1100, wins: 68, losses: 32 },
  ...Array.from({length: 8}, (_, i) => ({id: i + 11, name: ['Даниил Васильев', 'Роман Павлов', 'Михаил Фёдоров', 'Андрей Зайцев', 'Владислав Белов', 'Павел Кузнецов', 'Олег Попов', 'Виктор Егоров'][i], nickname: ['danil', 'roman', 'mike', 'andrew', 'vlad', 'pavel', 'oleg', 'victor'][i], phone: `+7 (900) 100-00-${i + 10}`, email: '', balance: 1000, wins: 20 + i * 5, losses: 12 + i * 3})),
];
export const demoComputers: Computer[] = Array.from({ length: 24 }, (_, i) => ({
  id: i + 1, name: `PC-${String(i + 1).padStart(2, '0')}`, zone: i >= 18 ? 'VIP-зал' : 'Основной зал',
  status: [5, 10, 17, 20].includes(i) ? 'free' : i === 22 ? 'offline' : i === 23 ? 'service' : [3, 14].includes(i) ? 'ending' : 'busy',
  ip: `192.168.1.${101 + i}`, specs: i >= 18 ? 'RTX 4080 · Intel i7-14700K · 32 GB' : 'RTX 4060 · Intel i5-13400F · 16 GB',
}));
export const demoOperators: Operator[] = [
  { id: 1, name: 'Алексей Козлов', role: 'Старший администратор', active: true },
  { id: 2, name: 'Мария Соколова', role: 'Администратор', active: true },
  { id: 3, name: 'Иван Мельников', role: 'Администратор', active: false },
];
export function makeDemo(now = new Date()): ClubData {
  const visits: Visit[] = demoComputers.filter(p => ['busy', 'ending'].includes(p.status)).map((p, i) => ({
    id: i + 1, clientId: i + 1, computerId: p.id, operatorId: i % 2 + 1,
    startedAt: new Date(now.getTime() - (20 + i * 6) * 60000).toISOString(),
    endsAt: new Date(now.getTime() + (p.status === 'ending' ? 8 : 35 + (i * 17) % 140) * 60000).toISOString(), finishedAt: null, amount: 600, wins: 0, losses: 0,
  }));
  for (let i = 0; i < 24; i++) {
    const start = new Date(now); start.setHours(8 + i % 6, i % 4 * 15, 0, 0);
    if (start > now) start.setTime(now.getTime() - (i + 2) * 3600000);
    const end = new Date(Math.min(start.getTime() + 3600000, now.getTime() - 60000));
    visits.push({id: 19 + i, clientId: i % 18 + 1, computerId: i % 24 + 1, operatorId: i % 3 + 1, startedAt: start.toISOString(), endsAt: end.toISOString(), finishedAt: end.toISOString(), amount: i === 0 ? 400 : 750, wins: i % 4, losses: i % 3});
  }
  for (let i = 0; i < 70; i++) {
    const start = new Date(now); start.setUTCDate(start.getUTCDate() - (1 + i % 14)); start.setUTCHours(10 + i % 12, 0, 0, 0);
    const end = new Date(start.getTime() + 2 * 3600000);
    visits.push({id: 43 + i, clientId: i % 18 + 1, computerId: i % 24 + 1, operatorId: i % 3 + 1, startedAt: start.toISOString(), endsAt: end.toISOString(), finishedAt: end.toISOString(), amount: 600 + i % 4 * 150, wins: i % 5, losses: i % 3});
  }
  const checks: ClubCheck[] = [...visits].sort((a,b)=>b.startedAt.localeCompare(a.startedAt)).slice(0,30).map((v,i)=>{
    const game = GAME_CATALOG[i%2]; const quantity = 1 + i%5; const created = new Date(new Date(v.startedAt).getTime() + 5*60000);
    const voided = Boolean(v.finishedAt) && i%7===3;
    return {id:i+1,computerId:v.computerId,clientId:i%4===3?null:v.clientId,operatorId:v.operatorId,game:game.name,quantity,unitPrice:game.price,amount:quantity*game.price,status:voided?'void':v.finishedAt?'paid':'open',createdAt:created.toISOString(),paidAt:v.finishedAt&&!voided?new Date(created.getTime()+3600000).toISOString():null};
  });
  return { clients: demoClients, computers: demoComputers, operators: demoOperators, visits, checks, agentConnected: false,
    cameras: [{id:1,name:'Камера 01',location:'Основной зал',url:'',kind:'mjpeg'},{id:2,name:'Камера 02',location:'Ресепшен',url:'',kind:'mjpeg'},{id:3,name:'Камера 03',location:'VIP-зал',url:'',kind:'mjpeg'},{id:4,name:'Камера 04',location:'Вход в клуб',url:'',kind:'mjpeg'}],
    events: [
      {id:1,type:'session',title:'Новая игровая сессия',detail:'PC-01 · Александр Петров · 2 часа',createdAt:new Date(now.getTime()-120000).toISOString()},
      {id:2,type:'payment',title:'Пополнение баланса',detail:'Максим Иванов · +1 000 ₽',createdAt:new Date(now.getTime()-420000).toISOString()},
      {id:3,type:'warning',title:'Компьютер не в сети',detail:'PC-23 · Проверьте подключение',createdAt:new Date(now.getTime()-720000).toISOString()},
      {id:4,type:'client',title:'Новый клиент',detail:'София Лебедева · Регистрация в клубе',createdAt:new Date(now.getTime()-1080000).toISOString()},
    ],
  };
}
