import { db } from '@/db';
import { clients, computers, operators, visits, checks, events, cameras } from '@/db/schema';
import { desc, sql } from 'drizzle-orm';
import { makeDemo, type ClubData } from './demo';

async function seedIfEmpty() {
  await db.transaction(async tx => {
    await tx.execute(sql`select pg_advisory_xact_lock(768410)`);
    if ((await tx.select().from(computers).limit(1)).length) return;
    const demo = makeDemo();
    await tx.insert(clients).values(demo.clients.map(c => ({...c, createdAt: c.createdAt ? new Date(c.createdAt) : new Date()})));
    await tx.insert(computers).values(demo.computers);
    await tx.insert(operators).values(demo.operators);
    await tx.insert(visits).values(demo.visits.map(v => ({...v, startedAt:new Date(v.startedAt), endsAt:new Date(v.endsAt), finishedAt:v.finishedAt ? new Date(v.finishedAt) : null})));
    await tx.insert(cameras).values(demo.cameras);
    await tx.insert(checks).values(demo.checks.map(c => ({...c, createdAt:new Date(c.createdAt), paidAt:c.paidAt ? new Date(c.paidAt) : null})));
    await tx.insert(events).values(demo.events.map(e => ({...e, createdAt:new Date(e.createdAt)})));
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_clients','id'), (select max(id) from club_clients))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_operators','id'), (select max(id) from club_operators))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_visits','id'), (select max(id) from club_visits))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_cameras','id'), (select max(id) from club_cameras))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_checks','id'), (select max(id) from club_checks))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('club_events','id'), (select max(id) from club_events))`);
  });
}

export async function loadClubData(): Promise<ClubData> {
  await seedIfEmpty();
  const [c, p, o, v, chk, e, cam] = await Promise.all([
    db.select().from(clients).orderBy(clients.id),
    db.select().from(computers).orderBy(computers.id),
    db.select().from(operators),
    db.select().from(visits).orderBy(desc(visits.startedAt)),
    db.select().from(checks).orderBy(desc(checks.createdAt)).limit(300),
    db.select().from(events).orderBy(desc(events.createdAt)).limit(100),
    db.select().from(cameras).orderBy(cameras.id),
  ]);
  return {
    clients: c.map(r => ({id:r.id,name:r.name,nickname:r.nickname,phone:r.phone,email:r.email,balance:r.balance,wins:r.wins,losses:r.losses,createdAt:r.createdAt.toISOString()})),
    computers: p.map(r => ({id:r.id,name:r.name,zone:r.zone,status:r.status,ip:r.ip,specs:r.specs})),
    operators: o.map(r => ({id:r.id,name:r.name,role:r.role,active:r.active})),
    visits: v.map(r => ({id:r.id,clientId:r.clientId,computerId:r.computerId,operatorId:r.operatorId,startedAt:r.startedAt.toISOString(),endsAt:r.endsAt.toISOString(),finishedAt:r.finishedAt ? r.finishedAt.toISOString() : null,amount:r.amount,wins:r.wins,losses:r.losses})),
    checks: chk.map(r => ({id:r.id,computerId:r.computerId,clientId:r.clientId,operatorId:r.operatorId,game:r.game,quantity:r.quantity,unitPrice:r.unitPrice,amount:r.amount,status:r.status,createdAt:r.createdAt.toISOString(),paidAt:r.paidAt ? r.paidAt.toISOString() : null})),
    events: e.map(r => ({id:r.id,type:r.type,title:r.title,detail:r.detail,createdAt:r.createdAt.toISOString()})),
    cameras: cam.map(r => ({id:r.id,name:r.name,location:r.location,url:r.url,kind:r.kind})),
    agentConnected: Boolean(process.env.LOCAL_AGENT_URL && process.env.LOCAL_AGENT_TOKEN),
  };
}
