export type GameInfo = { name: string; price: number; short: string };

export const GAME_CATALOG: GameInfo[] = [
  { name: 'Супер Matic', price: 50, short: 'MATIC' },
  { name: 'Чемпионы StarLine', price: 100, short: 'STARLINE' },
];

export const GAME_NAMES = GAME_CATALOG.map((g) => g.name);

export const CHECK_STATUS: Record<string, string> = {
  open: 'К оплате',
  paid: 'Оплачен',
  void: 'Аннулирован',
};

export function checkNumber(id: number) {
  return `ЧК-${String(id).padStart(6, '0')}`;
}

export function gameOf(name: string) {
  return GAME_CATALOG.find((g) => g.name === name);
}
